package com.shinobiarts.client;

import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.JutsuCharge;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.client.Minecraft;
import net.minecraft.client.gui.Font;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.player.LocalPlayer;
import net.minecraft.network.chat.Component;
import net.minecraftforge.client.gui.overlay.IGuiOverlay;

/**
 * The charge counter under the crosshair while right-click is held with a release:
 * <pre>
 *        Great Fireball
 *   [■■■■■■■■■■□□□□]  73%
 *          x1.26 damage
 * </pre>
 * The bar fills in the release's colour and turns gold and pulses at a full charge ("MAX"). If the jutsu is cooling
 * down or you're short on chakra, the bar greys out and says so, since letting go won't cast it.
 */
public final class ChargeHud {
    private static final int BAR_W = 90, BAR_H = 6;

    public static final IGuiOverlay OVERLAY = (gui, g, partialTick, width, height) -> render(g, width, height, partialTick);

    private ChargeHud() {}

    private static void render(GuiGraphics g, int width, int height, float partialTick) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (mc.options.hideGui || player == null || mc.level == null || !player.isUsingItem()) return;
        if (!(player.getUseItem().getItem() instanceof ReleaseItem item)) return;
        NinjaData d = ClientNinjaData.get();
        if (!d.hasNature(item.release())) return;
        Jutsu jutsu = d.selectedJutsu(item.release());
        if (jutsu == null || !JutsuCharge.chargeable(jutsu)) return;

        Font font = mc.font;
        int held = player.getTicksUsingItem();
        float frac = Math.min(1f, (held + partialTick) / JutsuCharge.fullChargeTicks(jutsu));
        boolean full = frac >= 1f;
        long now = mc.level.getGameTime();
        long cooldown = d.cooldownRemaining(jutsu.id(), now);
        boolean lowChakra = !player.getAbilities().instabuild && d.getChakra() < jutsu.cost(d);
        boolean blocked = cooldown > 0 || lowChakra;

        int cx = width / 2, top = height / 2 + 14;
        int x = cx - BAR_W / 2, y = top + 11;

        // jutsu name
        String name = ShinobiHud.shortName(jutsu);
        g.drawString(font, name, cx - font.width(name) / 2, top, 0xFFFFFFFF, true);

        // bar: dark frame, track, fill, quarter ticks
        int rgb = item.release().rgb();
        float pulse = full ? 0.75f + 0.25f * (float) Math.sin((now + partialTick) * 0.6) : 1f;
        int fillColor = blocked ? 0xFF6A6A6A : full ? shade(0xFFE8B83A, pulse) : 0xFF000000 | rgb;
        g.fill(x - 2, y - 2, x + BAR_W + 2, y + BAR_H + 2, 0xB0000000);
        g.fill(x - 1, y - 1, x + BAR_W + 1, y + BAR_H + 1, blocked ? 0xFF555555 : full ? fillColor : 0xFF2A2A34);
        g.fill(x, y, x + BAR_W, y + BAR_H, 0xFF14141A);
        int filled = Math.round(BAR_W * frac);
        if (filled > 0) {
            g.fill(x, y, x + filled, y + BAR_H, fillColor);
            g.fill(x, y, x + filled, y + 2, 0x50FFFFFF); // highlight along the top
        }
        for (int q = 1; q < 4; q++) g.fill(x + BAR_W * q / 4, y, x + BAR_W * q / 4 + 1, y + BAR_H, 0x60000000);

        // counter to the right of the bar
        String counter;
        int counterColor;
        if (cooldown > 0) {
            counter = String.format(java.util.Locale.ROOT, "%.1fs", cooldown / 20f);
            counterColor = 0xFFFF5555;
        } else if (lowChakra) {
            counter = Component.translatable("hud.shinobiarts.charge_low").getString();
            counterColor = 0xFFFF5555;
        } else if (full) {
            counter = Component.translatable("hud.shinobiarts.charge_max").getString();
            counterColor = shade(0xFFFFD34A, pulse);
        } else {
            counter = Math.round(frac * 100) + "%";
            counterColor = 0xFFFFFFFF;
        }
        g.drawString(font, counter, x + BAR_W + 6, y - 1, counterColor, true);

        // what letting go will do
        Component below = blocked
                ? Component.translatable(cooldown > 0 ? "hud.shinobiarts.charge_cooldown" : "hud.shinobiarts.charge_no_chakra")
                : Component.translatable("hud.shinobiarts.charge_power",
                String.format(java.util.Locale.ROOT, "%.2f", JutsuCharge.power(jutsu, held)));
        float s = 0.75f;
        g.pose().pushPose();
        g.pose().translate(cx - font.width(below) * s / 2f, y + BAR_H + 4, 0);
        g.pose().scale(s, s, 1f);
        g.drawString(font, below, 0, 0, blocked ? 0xFFFF7777 : full ? 0xFFFFE08A : 0xFFD0D0D0, true);
        g.pose().popPose();
    }

    private static int shade(int argb, float f) {
        int r = Math.min(255, Math.round(((argb >> 16) & 0xFF) * f));
        int gr = Math.min(255, Math.round(((argb >> 8) & 0xFF) * f));
        int b = Math.min(255, Math.round((argb & 0xFF) * f));
        return (argb & 0xFF000000) | (r << 16) | (gr << 8) | b;
    }
}
