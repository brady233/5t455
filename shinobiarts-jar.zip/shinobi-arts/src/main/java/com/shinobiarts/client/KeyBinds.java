package com.shinobiarts.client;

import com.mojang.blaze3d.platform.InputConstants;
import net.minecraft.client.KeyMapping;
import net.minecraftforge.client.settings.KeyConflictContext;
import org.lwjgl.glfw.GLFW;

/**
 * Default keys; players can rebind them under Options > Controls > Naruto Generations.
 * Ninja Jump uses the vanilla Sneak + Jump keys, so it follows whatever those are bound to.
 */
public final class KeyBinds {
    public static final String CATEGORY = "key.categories.shinobiarts";

    public static final KeyMapping NEXT = key("next", GLFW.GLFW_KEY_G);
    public static final KeyMapping PREV = key("prev", GLFW.GLFW_KEY_H);
    public static final KeyMapping DOJUTSU = key("dojutsu", GLFW.GLFW_KEY_V);
    public static final KeyMapping CHARGE = key("charge", GLFW.GLFW_KEY_Z);
    public static final KeyMapping SAGE = key("sage", GLFW.GLFW_KEY_B);
    public static final KeyMapping STATS = key("stats", GLFW.GLFW_KEY_J);
    // eye techniques of an active Sharingan (Amaterasu, Kamui, Genjutsu...): see ninja/EyeTechniques
    public static final KeyMapping JUTSU_1 = key("jutsu_1", GLFW.GLFW_KEY_R);
    public static final KeyMapping JUTSU_2 = key("jutsu_2", GLFW.GLFW_KEY_Y);
    public static final KeyMapping JUTSU_3 = key("jutsu_3", GLFW.GLFW_KEY_U);

    public static final KeyMapping[] ALL = {NEXT, PREV, DOJUTSU, CHARGE, SAGE, STATS, JUTSU_1, JUTSU_2, JUTSU_3};
    public static final KeyMapping[] JUTSU_KEYS = {JUTSU_1, JUTSU_2, JUTSU_3};

    private static KeyMapping key(String name, int keyCode) {
        return new KeyMapping("key.shinobiarts." + name, KeyConflictContext.IN_GAME, InputConstants.Type.KEYSYM, keyCode, CATEGORY);
    }

    private KeyBinds() {}
}
