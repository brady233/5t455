package com.shinobiarts.client;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.ninja.SharinganManager;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.geom.EntityModelSet;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.RenderLayerParent;
import net.minecraft.client.renderer.entity.layers.RenderLayer;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.LivingEntity;

/**
 * Lightning Armor: a crackling shell of blue sparks around the body (textures/entity/lightning_armor.png, scrolling
 * like a charged creeper's glow) while the jutsu is up. Everyone nearby sees it.
 */
public class LightningArmorLayer<T extends LivingEntity, M extends HumanoidModel<T>> extends RenderLayer<T, M> {
    private static final ResourceLocation TEXTURE = new ResourceLocation(ShinobiArts.MODID, "textures/entity/lightning_armor.png");
    private final HumanoidModel<T> shell;

    public LightningArmorLayer(RenderLayerParent<T, M> parent, EntityModelSet models) {
        super(parent);
        this.shell = new HumanoidModel<>(models.bakeLayer(ClientSetup.LIGHTNING_ARMOR_LAYER));
    }

    @Override
    public void render(PoseStack poseStack, MultiBufferSource buffer, int packedLight, T entity, float limbSwing,
                       float limbSwingAmount, float partialTick, float ageInTicks, float netHeadYaw, float headPitch) {
        if ((ClientEyes.look(entity) & SharinganManager.LOOK_LIGHTNING) == 0 || entity.isInvisible()) return;
        getParentModel().copyPropertiesTo(shell);
        shell.setAllVisible(true);
        float t = entity.tickCount + partialTick;
        VertexConsumer consumer = buffer.getBuffer(RenderType.energySwirl(TEXTURE, (t * 0.02f) % 1f, (t * 0.013f) % 1f));
        shell.renderToBuffer(poseStack, consumer, LightTexture.FULL_BRIGHT, OverlayTexture.NO_OVERLAY, 0.9f, 0.95f, 1f, 1f);
    }
}
