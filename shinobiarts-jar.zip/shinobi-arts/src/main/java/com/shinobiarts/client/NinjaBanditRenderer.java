package com.shinobiarts.client;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.entity.NinjaBandit;
import net.minecraft.client.model.HumanoidModel;
import net.minecraft.client.model.PlayerModel;
import net.minecraft.client.model.geom.ModelLayers;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.entity.HumanoidMobRenderer;
import net.minecraft.client.renderer.entity.layers.HumanoidArmorLayer;
import net.minecraft.resources.ResourceLocation;

/** Ninja bandits: player-shaped, with a masked outfit whose scarf and headband show their nature. */
public class NinjaBanditRenderer extends HumanoidMobRenderer<NinjaBandit, PlayerModel<NinjaBandit>> {
    private static final ResourceLocation[] TEXTURES = {
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/ninja_bandit_fire.png"),
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/ninja_bandit_water.png"),
            new ResourceLocation(ShinobiArts.MODID, "textures/entity/ninja_bandit_earth.png"),
    };

    public NinjaBanditRenderer(EntityRendererProvider.Context context) {
        super(context, new PlayerModel<>(context.bakeLayer(ModelLayers.PLAYER), false), 0.5f);
        this.addLayer(new HumanoidArmorLayer<>(this,
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_INNER_ARMOR)),
                new HumanoidModel<>(context.bakeLayer(ModelLayers.PLAYER_OUTER_ARMOR)),
                context.getModelManager()));
    }

    @Override
    public ResourceLocation getTextureLocation(NinjaBandit bandit) {
        return TEXTURES[bandit.getElement().ordinal()];
    }
}
