package com.shinobiarts.entity;

import com.shinobiarts.Config;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModItems;
import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.DifficultyInstance;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.EquipmentSlot;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.MobSpawnType;
import net.minecraft.world.entity.SpawnGroupData;
import net.minecraft.world.entity.ai.attributes.AttributeSupplier;
import net.minecraft.world.entity.ai.attributes.Attributes;
import net.minecraft.world.entity.ai.goal.FloatGoal;
import net.minecraft.world.entity.ai.goal.Goal;
import net.minecraft.world.entity.ai.goal.LookAtPlayerGoal;
import net.minecraft.world.entity.ai.goal.MeleeAttackGoal;
import net.minecraft.world.entity.ai.goal.RandomLookAroundGoal;
import net.minecraft.world.entity.ai.goal.WaterAvoidingRandomStrollGoal;
import net.minecraft.world.entity.ai.goal.target.HurtByTargetGoal;
import net.minecraft.world.entity.ai.goal.target.NearestAttackableTargetGoal;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.ServerLevelAccessor;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.phys.Vec3;

import javax.annotation.Nullable;
import java.util.EnumSet;

/**
 * A rogue ninja. Each bandit is trained in one nature: Fire (fireballs), Water (water bullets) or Earth (spikes
 * that burst from the ground under you). They keep their distance to cast, close in with a kunai, and drop Ryo.
 * They roam the overworld in small groups, by day and night.
 */
public class NinjaBandit extends Monster {
    public enum Element { FIRE, WATER, EARTH }

    private static final EntityDataAccessor<Byte> ELEMENT = SynchedEntityData.defineId(NinjaBandit.class, EntityDataSerializers.BYTE);

    public NinjaBandit(EntityType<? extends NinjaBandit> type, Level level) {
        super(type, level);
        this.xpReward = 10;
    }

    public static AttributeSupplier.Builder createAttributes() {
        return Monster.createMonsterAttributes()
                .add(Attributes.MAX_HEALTH, 30.0)
                .add(Attributes.MOVEMENT_SPEED, 0.3)
                .add(Attributes.ATTACK_DAMAGE, 4.0)
                .add(Attributes.ARMOR, 4.0)
                .add(Attributes.FOLLOW_RANGE, 32.0);
    }

    @Override
    protected void defineSynchedData() {
        super.defineSynchedData();
        this.entityData.define(ELEMENT, (byte) 0);
    }

    public Element getElement() {
        return Element.values()[Math.max(0, Math.min(2, this.entityData.get(ELEMENT)))];
    }

    @Override
    protected void registerGoals() {
        this.goalSelector.addGoal(0, new FloatGoal(this));
        this.goalSelector.addGoal(1, new JutsuGoal(this));
        this.goalSelector.addGoal(2, new MeleeAttackGoal(this, 1.15, false));
        this.goalSelector.addGoal(5, new WaterAvoidingRandomStrollGoal(this, 0.9));
        this.goalSelector.addGoal(6, new LookAtPlayerGoal(this, Player.class, 10.0f));
        this.goalSelector.addGoal(7, new RandomLookAroundGoal(this));
        this.targetSelector.addGoal(1, new HurtByTargetGoal(this));
        this.targetSelector.addGoal(2, new NearestAttackableTargetGoal<>(this, Player.class, true));
        this.targetSelector.addGoal(3, new NearestAttackableTargetGoal<>(this, ShadowClone.class, true));
    }

    @Override
    @Nullable
    public SpawnGroupData finalizeSpawn(ServerLevelAccessor level, DifficultyInstance difficulty, MobSpawnType reason,
                                        @Nullable SpawnGroupData data, @Nullable CompoundTag tag) {
        SpawnGroupData result = super.finalizeSpawn(level, difficulty, reason, data, tag);
        this.entityData.set(ELEMENT, (byte) this.random.nextInt(3));
        setItemSlot(EquipmentSlot.MAINHAND, new ItemStack(ModItems.KUNAI.get()));
        setDropChance(EquipmentSlot.MAINHAND, 0.15f);
        return result;
    }

    /** Casts this bandit's jutsu at the target. */
    void castJutsu(LivingEntity target) {
        if (!(level() instanceof ServerLevel level)) return;
        float damage = Config.f(Config.BANDIT_JUTSU_DAMAGE);
        swing(InteractionHand.MAIN_HAND);
        switch (getElement()) {
            case FIRE -> {
                JutsuProjectile.shootAt(this, this, JutsuProjectile.Kind.FIRE_BALL, 1.1f, damage, target);
                playSound(SoundEvents.BLAZE_SHOOT, 1.0f, 1.0f);
            }
            case WATER -> {
                JutsuProjectile.shootAt(this, this, JutsuProjectile.Kind.WATER_BULLET, 1.8f, damage, target);
                playSound(SoundEvents.PLAYER_SPLASH, 0.8f, 1.4f);
            }
            case EARTH -> {
                Vec3 at = target.position();
                target.hurt(ModDamage.jutsu(level, this, this), damage);
                JutsuUtil.push(target, new Vec3(0, 0.9, 0));
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.DIRT.defaultBlockState()),
                        at.x, at.y + 0.2, at.z, 40, 0.6, 0.3, 0.6, 0.2);
                level.sendParticles(new BlockParticleOption(ParticleTypes.BLOCK, Blocks.STONE.defaultBlockState()),
                        at.x, at.y + 0.2, at.z, 25, 0.5, 0.6, 0.5, 0.2);
                level.playSound(null, at.x, at.y, at.z, SoundEvents.ROOTED_DIRT_BREAK, getSoundSource(), 1.2f, 0.7f);
            }
        }
    }

    /** Ryo in coins (gold 1,000, silver 500, bronze 100). */
    @Override
    protected void dropCustomDeathLoot(DamageSource source, int looting, boolean hitByPlayer) {
        super.dropCustomDeathLoot(source, looting, hitByPlayer);
        int min = Config.i(Config.BANDIT_RYO_MIN), max = Math.max(min, Config.i(Config.BANDIT_RYO_MAX));
        int ryo = (min + this.random.nextInt(max - min + 1)) * (1 + looting) / 100 * 100;
        for (CoinItem.Coin coin : new CoinItem.Coin[]{CoinItem.Coin.GOLD, CoinItem.Coin.SILVER, CoinItem.Coin.BRONZE}) {
            int n = ryo / coin.value();
            ryo -= n * coin.value();
            if (n > 0) spawnAtLocation(new ItemStack(ModItems.coin(coin), n));
        }
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putByte("Element", this.entityData.get(ELEMENT));
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.entityData.set(ELEMENT, tag.getByte("Element"));
    }

    /** Keeps a few blocks away and casts every few seconds; the melee goal takes over up close. */
    static class JutsuGoal extends Goal {
        private final NinjaBandit bandit;
        private int cooldown = 40;

        JutsuGoal(NinjaBandit bandit) {
            this.bandit = bandit;
            setFlags(EnumSet.of(Goal.Flag.MOVE, Goal.Flag.LOOK));
        }

        @Override
        public boolean canUse() {
            LivingEntity t = bandit.getTarget();
            if (t == null || !t.isAlive()) return false;
            double d = bandit.distanceToSqr(t);
            return d > 16.0 && d < 324.0;
        }

        @Override
        public boolean canContinueToUse() {
            return canUse();
        }

        @Override
        public boolean requiresUpdateEveryTick() {
            return true;
        }

        @Override
        public void tick() {
            LivingEntity t = bandit.getTarget();
            if (t == null) return;
            bandit.getLookControl().setLookAt(t, 30.0f, 30.0f);
            double d = bandit.distanceToSqr(t);
            if (d > 144.0) bandit.getNavigation().moveTo(t, 1.0);
            else bandit.getNavigation().stop();
            if (--cooldown <= 0 && bandit.hasLineOfSight(t)) {
                bandit.castJutsu(t);
                cooldown = 50 + bandit.getRandom().nextInt(40);
            }
        }
    }

    @Override
    public boolean removeWhenFarAway(double distanceSqr) {
        return distanceSqr > 128 * 128;
    }

    @Override
    public boolean isAlliedTo(net.minecraft.world.entity.Entity other) {
        return other instanceof NinjaBandit || super.isAlliedTo(other);
    }

    public static boolean checkSpawn(EntityType<NinjaBandit> type, ServerLevelAccessor level, MobSpawnType reason,
                                     net.minecraft.core.BlockPos pos, net.minecraft.util.RandomSource random) {
        return Monster.checkAnyLightMonsterSpawnRules(type, level, reason, pos, random) && level.canSeeSky(pos);
    }
}
