package com.shinobiarts.jutsu;

import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.network.chat.Component;

import javax.annotation.Nullable;

/** Who may learn what from a scroll. */
public final class LearnRules {
    private LearnRules() {}

    /** Returns the reason the jutsu can't be learned, or null if it can. */
    @Nullable
    public static Component check(NinjaData data, Jutsu jutsu) {
        if (data.knows(jutsu.id())) {
            return Component.translatable("message.shinobiarts.already_known", jutsu.displayName()).withStyle(ChatFormatting.GRAY);
        }
        if (jutsu.needsDojutsu() && data.getSharinganStage() <= 0) {
            return Component.translatable("message.shinobiarts.need_sharingan").withStyle(ChatFormatting.RED);
        }
        if (jutsu.clan() != null && data.getClan() != jutsu.clan()) {
            return Component.translatable("message.shinobiarts.wrong_clan", jutsu.clan().displayName()).withStyle(ChatFormatting.RED);
        }
        if (jutsu.nature().isElement() && !data.hasNature(jutsu.nature())) {
            if (!data.isAffinityRevealed()) {
                return Component.translatable("message.shinobiarts.need_affinity").withStyle(ChatFormatting.RED);
            }
            return Component.translatable("message.shinobiarts.need_nature", jutsu.nature().displayName()).withStyle(ChatFormatting.RED);
        }
        if (data.getLevel() < jutsu.requiredLevel()) {
            return Component.translatable("message.shinobiarts.need_level", jutsu.requiredLevel(), data.getLevel())
                    .withStyle(ChatFormatting.RED);
        }
        return null;
    }
}
