package com.shinobiarts.jutsu;

import com.shinobiarts.Config;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.ninja.Clan;
import com.shinobiarts.ninja.Dojutsu;
import com.shinobiarts.ninja.SharinganManager;
import com.shinobiarts.ninja.NinjaData;
import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.network.chat.Component;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

/** Per-tick server logic for every player: regen, charging, eye techniques and active buffs. */
public final class NinjaTicker {
    /** Chakra per second drained while Sharingan/Byakugan is active. */
    public static final float DOJUTSU_DRAIN = 3f;
    /** Extra chakra per second while charging. */
    public static final float CHARGE_RATE = 12f;
    public static final double BYAKUGAN_RANGE = 32.0;

    private static final DustParticleOptions CHARGE_DUST = new DustParticleOptions(new Vector3f(0.35f, 0.7f, 1.0f), 1.0f);
    private static final DustParticleOptions SENJUTSU_DUST = new DustParticleOptions(new Vector3f(0.35f, 0.85f, 0.35f), 1.0f);
    private static final DustParticleOptions RASENGAN_DUST = new DustParticleOptions(new Vector3f(0.55f, 0.85f, 1.0f), 0.8f);

    private NinjaTicker() {}

    public static void tick(ServerPlayer player) {
        NinjaData data = NinjaData.get(player);
        if (data == null || !data.isInitialized() || !player.isAlive()) return;
        ServerLevel level = player.serverLevel();
        long now = level.getGameTime();
        int chakraBefore = (int) data.getChakra();
        int senjutsuBefore = (int) data.getSenjutsu();
        boolean dirty = false;

        // Natural regeneration + eye technique upkeep, once per second.
        if (player.tickCount % 20 == 0) {
            data.addChakra(data.regenPerSecond());
            if (data.isDojutsuActive()) {
                Dojutsu eyes = data.getActiveDojutsu();
                if (!data.availableDojutsu().contains(eyes) || (data.getChakra() < DOJUTSU_DRAIN && !player.getAbilities().instabuild)) {
                    data.setActiveDojutsu(Dojutsu.NONE);
                    if (eyes == Dojutsu.BYAKUGAN) player.removeEffect(MobEffects.NIGHT_VISION);
                    player.displayClientMessage(Component.translatable("message.shinobiarts.dojutsu_off", data.dojutsuName(eyes)), true);
                    if (eyes == Dojutsu.SHARINGAN) SharinganManager.broadcastEyes(player);
                    dirty = true;
                } else {
                    if (!player.getAbilities().instabuild) data.consumeChakra(DOJUTSU_DRAIN);
                    applyDojutsu(player, data);
                }
            }
        }

        clanPassives(player, data);

        // Charging chakra: fast regen, but you're rooted in place and get hungry.
        if (data.isCharging()) {
            if (player.tickCount % 4 == 0) {
                data.addChakra(CHARGE_RATE / 5f * Config.f(Config.CHAKRA_REGEN_MULTIPLIER));
                player.causeFoodExhaustion(0.03f);
                // Standing perfectly still while charging also gathers natural energy (Senjutsu).
                Vec3 motion = player.getDeltaMovement();
                if (data.maxSenjutsu() > 0 && motion.x * motion.x + motion.z * motion.z < 1.0e-4) {
                    data.setSenjutsu(data.getSenjutsu() + Config.f(Config.SENJUTSU_GATHER_RATE) / 5f);
                    if (player.tickCount % 8 == 0) {
                        level.sendParticles(SENJUTSU_DUST, player.getX(), player.getY() + 0.2, player.getZ(), 4, 0.6, 0.1, 0.6, 0.0);
                    }
                }
            }
            if (player.tickCount % 10 == 0) {
                player.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 15, 3, false, false, false));
            }
            if (player.tickCount % 3 == 0) {
                double a = (player.tickCount % 40) / 40.0 * Math.PI * 2;
                for (int i = 0; i < 3; i++) {
                    double ang = a + i * (Math.PI * 2 / 3);
                    level.sendParticles(CHARGE_DUST, player.getX() + Math.cos(ang) * 0.7, player.getY() + 0.1,
                            player.getZ() + Math.sin(ang) * 0.7, 1, 0.05, 0.4, 0.05, 0.0);
                }
            }
        }

        // Sage Mode: drains natural energy, keeps its buffs up, ends when Senjutsu runs out.
        if (data.isSageMode()) {
            if (player.tickCount % 20 == 0) {
                data.setSenjutsu(data.getSenjutsu() - Config.f(Config.SAGE_MODE_DRAIN));
                if (data.getSenjutsu() <= 0 || data.maxSenjutsu() <= 0) {
                    data.setSageMode(false);
                    player.displayClientMessage(Component.translatable("message.shinobiarts.sage_off"), true);
                    dirty = true;
                } else {
                    applySageMode(player);
                }
            }
            if (player.tickCount % 5 == 0) {
                level.sendParticles(SENJUTSU_DUST, player.getX(), player.getY() + 1.0, player.getZ(), 2, 0.35, 0.6, 0.35, 0.0);
            }
        }

        // Rasengan spinning in the right hand.
        if (data.getRasenganUntil() != 0) {
            if (data.getRasenganUntil() > now) {
                Vec3 look = player.getLookAngle();
                Vec3 hand = player.getEyePosition().add(look.scale(0.55)).add(JutsuUtil.right(player).scale(0.38)).add(0, -0.45, 0);
                level.sendParticles(RASENGAN_DUST, hand.x, hand.y, hand.z, 4, 0.08, 0.08, 0.08, 0.0);
                if (player.tickCount % 4 == 0) {
                    level.sendParticles(net.minecraft.core.particles.ParticleTypes.ENCHANTED_HIT, hand.x, hand.y, hand.z, 1, 0.05, 0.05, 0.05, 0.0);
                }
            } else {
                data.setRasenganUntil(0);
                dirty = true;
            }
        }

        // Mangekyou: awakened by surviving a near-death experience.
        if (player.tickCount % 5 == 0) SharinganManager.checkMangekyou(player, data);

        // Eye techniques: sneaking puts out Amaterasu, Kamui's upkeep, and what other players see.
        com.shinobiarts.ninja.EyeTechniques.tick(player, data, now);

        // Combat tag running out.
        if (data.getCombatUntil() != 0 && data.getCombatUntil() <= now) {
            data.clearCombat();
            player.displayClientMessage(Component.translatable("message.shinobiarts.combat_over").withStyle(ChatFormatting.GREEN), true);
            dirty = true;
        }

        // XP boost counts down while you're online.
        if (data.getBoostTicks() > 0) {
            data.setBoost(data.getBoostMultiplier(), data.getBoostTicks() - 1);
            if (data.getBoostTicks() == 0) {
                player.sendSystemMessage(Component.translatable("message.shinobiarts.boost_over").withStyle(ChatFormatting.GRAY));
                data.setBoost(1f, 0);
                dirty = true;
            }
        }

        // Palm Rotation spin.
        if (data.getRotationUntil() != 0) {
            if (data.getRotationUntil() > now) JutsuEffects.rotationTick(player);
            else {
                data.setRotationUntil(0);
                dirty = true;
            }
        }

        // Expire an unused substitution.
        if (data.getSubstitutionUntil() != 0 && data.getSubstitutionUntil() <= now) {
            data.setSubstitutionUntil(0);
            dirty = true;
        }

        if (dirty || (int) data.getChakra() != chakraBefore || (int) data.getSenjutsu() != senjutsuBefore) ModNetwork.sync(player);
    }

    /** Range of the clans that sense creatures nearby (Aburame insects, Inuzuka noses...). */
    public static final double SENSE_RANGE = 16.0;

    /**
     * Clan passives: health regeneration every 5 seconds, lasting night vision / water breathing, Dolphin's Grace in
     * water, and for sensor clans, nearby creatures glow while the player sneaks.
     */
    private static void clanPassives(ServerPlayer player, NinjaData data) {
        com.shinobiarts.ninja.ClanBuffs b = data.getClan().buffs();
        if (b.regen() > 0 && player.tickCount % 100 == 0 && player.getHealth() < player.getMaxHealth()) player.heal(b.regen());
        if (player.tickCount % 80 == 0) {
            if (b.hasNightVision()) player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, true, false, true));
            if (b.breathesUnderwater()) player.addEffect(new MobEffectInstance(MobEffects.WATER_BREATHING, 200, 0, true, false, true));
        }
        if (b.swimsFast() && player.isInWater() && player.tickCount % 20 == 0) {
            player.addEffect(new MobEffectInstance(MobEffects.DOLPHINS_GRACE, 40, 0, true, false, true));
        }
        if (b.senses() && player.isShiftKeyDown() && player.tickCount % 20 == 0) {
            for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class, player.getBoundingBox().inflate(SENSE_RANGE),
                    cand -> cand != player && cand.isAlive())) {
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false, false));
            }
        }
    }

    /** Refreshes Sage Mode's buffs (jutsu damage bonus is applied in the damage event). */
    public static void applySageMode(ServerPlayer player) {
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_BOOST, 40, 0, false, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.DAMAGE_RESISTANCE, 40, 0, false, false, true));
        player.addEffect(new MobEffectInstance(MobEffects.JUMP, 40, 0, false, false, true));
    }

    /** Refreshes the passive effects of an active eye technique. */
    public static void applyDojutsu(ServerPlayer player, NinjaData data) {
        if (data.getActiveDojutsu() == Dojutsu.BYAKUGAN) {
            // Byakugan: see in the dark and see every creature nearby through walls.
            player.addEffect(new MobEffectInstance(MobEffects.NIGHT_VISION, 400, 0, false, false, true));
            for (LivingEntity e : player.level().getEntitiesOfClass(LivingEntity.class,
                    player.getBoundingBox().inflate(BYAKUGAN_RANGE), cand -> cand != player && cand.isAlive())) {
                e.addEffect(new MobEffectInstance(MobEffects.GLOWING, 30, 0, false, false, false));
            }
        }
        // Sharingan's dodge and copy are handled in the damage event and JutsuCaster.
    }
}
