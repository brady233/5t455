package com.shinobiarts.ninja;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.block.AmaterasuFireBlock;
import com.shinobiarts.jutsu.JutsuEffects;
import com.shinobiarts.jutsu.JutsuUtil;
import com.shinobiarts.network.ModNetwork;
import com.shinobiarts.registry.ModBlocks;
import com.shinobiarts.registry.ModDamage;
import com.shinobiarts.registry.ModEffects;
import net.minecraft.ChatFormatting;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.core.particles.DustParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;
import net.minecraft.network.chat.MutableComponent;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import org.joml.Vector3f;

import javax.annotation.Nullable;

/**
 * The techniques of an active Sharingan, on the Jutsu 1 / Jutsu 2 / Jutsu 3 keys (R / Y / U by default):
 * <ul>
 *   <li>Jutsu 1, Amaterasu (Itachi, Sasuke and Eternal Mangekyou): black flames on the spot you look at, and on the
 *       creature there. Sneaking with the Mangekyou on puts out every black flame around you.</li>
 *   <li>Jutsu 2, Kamui (Obito's Mangekyou): you turn intangible for a few seconds (press again to end it early).
 *       Sneak + Jutsu 2 is the Kamui snap: it tears at the creature you look at for half its max health.</li>
 *   <li>Jutsu 3, Genjutsu (every Sharingan): traps the creature you look at in an illusion.</li>
 * </ul>
 * Each costs a share of max chakra and has its own cooldown (config section {@code eyeTechniques}).
 * The client uses {@link #technique} too, to draw the HUD's technique slots.
 */
public final class EyeTechniques {
    private static final DustParticleOptions BLACK_FLAME = new DustParticleOptions(new Vector3f(0.06f, 0.0f, 0.08f), 2.0f);
    private static final DustParticleOptions KAMUI_DUST = new DustParticleOptions(new Vector3f(0.12f, 0.05f, 0.2f), 1.3f);
    private static final DustParticleOptions GENJUTSU_DUST = new DustParticleOptions(new Vector3f(0.8f, 0.05f, 0.1f), 1.3f);

    public enum Technique {
        AMATERASU("amaterasu", 1),
        KAMUI("kamui", 2),
        KAMUI_SNAP("kamui_snap", 2),
        GENJUTSU("genjutsu", 3);

        private final String id;
        private final int key;

        Technique(String id, int key) {
            this.id = id;
            this.key = key;
        }

        public String id() {
            return id;
        }

        /** Which Jutsu key (1-3) uses it. */
        public int key() {
            return key;
        }

        public String cooldownId() {
            return "eye_" + id;
        }

        public MutableComponent displayName() {
            return Component.translatable("eye.shinobiarts." + id);
        }

        /** The HUD icon: textures/gui/eye_<id>.png (64 x 64). */
        public ResourceLocation icon() {
            return ShinobiArts.id("textures/gui/eye_" + id + ".png");
        }

        /** Share of max chakra it costs. */
        public float cost() {
            return switch (this) {
                case AMATERASU -> Config.f(Config.AMATERASU_COST);
                case KAMUI -> Config.f(Config.KAMUI_COST);
                case KAMUI_SNAP -> Config.f(Config.KAMUI_SNAP_COST);
                case GENJUTSU -> Config.f(Config.GENJUTSU_COST);
            };
        }

        /** Cooldown in ticks (scaled by cooldownMultiplier). Kamui's starts when the intangibility ends. */
        public long cooldownTicks() {
            int seconds = switch (this) {
                case AMATERASU -> Config.i(Config.AMATERASU_COOLDOWN);
                case KAMUI -> Config.i(Config.KAMUI_COOLDOWN);
                case KAMUI_SNAP -> Config.i(Config.KAMUI_SNAP_COOLDOWN);
                case GENJUTSU -> Config.i(Config.GENJUTSU_COOLDOWN);
            };
            return Math.max(0L, Math.round(seconds * 20 * Config.d(Config.COOLDOWN_MULTIPLIER)));
        }
    }

    private EyeTechniques() {}

    /** The technique a Jutsu key (1-3) gives this player's eyes, or null. Doesn't check whether the eyes are on. */
    @Nullable
    public static Technique technique(NinjaData d, int key, boolean sneaking) {
        int stage = d.getSharinganStage();
        if (stage <= 0) return null;
        MangekyouDesign design = d.getMangekyouDesign();
        boolean mangekyou = stage == Dojutsu.MANGEKYOU;
        return switch (key) {
            case 1 -> mangekyou && design.hasAmaterasu() ? Technique.AMATERASU : null;
            case 2 -> mangekyou && design.hasKamui() ? (sneaking ? Technique.KAMUI_SNAP : Technique.KAMUI) : null;
            case 3 -> Technique.GENJUTSU;
            default -> null;
        };
    }

    // ================================================================ using a technique

    /** A Jutsu key was pressed. Everything is checked here; the client only says which key. */
    public static void use(ServerPlayer p, int key, boolean sneaking) {
        NinjaData d = NinjaData.get(p);
        if (d == null || !d.isInitialized() || !p.isAlive() || p.isSpectator()) return;
        long now = p.level().getGameTime();
        Technique t = technique(d, key, sneaking || p.isShiftKeyDown());
        if (t == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.no_eye_technique", key).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        if (t == Technique.KAMUI && d.isIntangible(now)) {
            endIntangible(p, d); // pressing Jutsu 2 again ends Kamui early
            return;
        }
        if (!d.isSharinganActive()) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.eyes_off", t.displayName()).withStyle(ChatFormatting.RED), true);
            return;
        }
        long remaining = d.cooldownRemaining(t.cooldownId(), now);
        if (remaining > 0) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.cooldown", t.displayName(),
                    String.format("%.1f", remaining / 20.0f)).withStyle(ChatFormatting.GRAY), true);
            return;
        }
        boolean creative = p.getAbilities().instabuild;
        float cost = d.maxChakra() * t.cost();
        if (!creative && d.getChakra() < cost) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.not_enough_chakra",
                    (int) d.getChakra(), (int) Math.ceil(cost)).withStyle(ChatFormatting.RED), true);
            return;
        }
        boolean done = switch (t) {
            case AMATERASU -> amaterasu(p, d);
            case KAMUI -> startKamui(p, d);
            case KAMUI_SNAP -> kamuiSnap(p, d);
            case GENJUTSU -> genjutsu(p, d);
        };
        if (!done) return;
        if (!creative) d.consumeChakra(cost);
        if (t != Technique.KAMUI) d.setCooldown(t.cooldownId(), now + t.cooldownTicks());
        p.displayClientMessage(t.displayName().withStyle(ChatFormatting.RED), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    private static void noTarget(ServerPlayer p) {
        p.displayClientMessage(Component.translatable("message.shinobiarts.no_target").withStyle(ChatFormatting.GRAY), true);
    }

    /** Using the Mangekyou's techniques hurts the eyes (not the Eternal Mangekyou's). */
    private static void strainEyes(ServerPlayer p, NinjaData d) {
        if (!d.getMangekyouDesign().strainsEyes()) return;
        p.addEffect(new MobEffectInstance(MobEffects.BLINDNESS, 40, 0));
        p.hurt(p.damageSources().magic(), 2.0f);
    }

    // ---------------------------------------------------------------- Amaterasu

    /** Black flames on the block you look at (and on the creature you look at, if any). */
    private static boolean amaterasu(ServerPlayer p, NinjaData d) {
        ServerLevel level = p.serverLevel();
        double range = Config.i(Config.AMATERASU_RANGE);
        Vec3 eye = p.getEyePosition();
        Vec3 end = eye.add(p.getLookAngle().scale(range));
        BlockHitResult blockHit = level.clip(new ClipContext(eye, end, ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        LivingEntity target = JutsuUtil.rayTarget(p, range);

        BlockPos center;
        if (target != null) {
            int amplifier = Math.min(3, d.stat(Stat.GENJUTSU) / 25);
            target.addEffect(new MobEffectInstance(ModEffects.AMATERASU.get(), Math.round(200 * d.genjutsuMultiplier()), amplifier), p);
            target.hurt(ModDamage.jutsu(level, p, p), JutsuUtil.dmg(4f));
            level.sendParticles(BLACK_FLAME, target.getX(), target.getY() + target.getBbHeight() / 2, target.getZ(), 80,
                    target.getBbWidth() * 0.6, target.getBbHeight() * 0.4, target.getBbWidth() * 0.6, 0.0);
            center = target.blockPosition();
        } else if (blockHit.getType() == HitResult.Type.BLOCK) {
            Direction face = blockHit.getDirection();
            center = blockHit.getBlockPos().relative(face);
        } else {
            noTarget(p);
            return false;
        }

        int placed = placeFlames(level, p, center);
        if (placed == 0 && target == null) {
            p.displayClientMessage(Component.translatable("message.shinobiarts.amaterasu_no_room").withStyle(ChatFormatting.GRAY), true);
            return false;
        }
        Vec3 c = Vec3.atBottomCenterOf(center);
        level.sendParticles(BLACK_FLAME, c.x, c.y + 0.5, c.z, 60, 1.0, 0.5, 1.0, 0.0);
        level.sendParticles(ParticleTypes.LARGE_SMOKE, c.x, c.y + 0.5, c.z, 20, 0.8, 0.4, 0.8, 0.02);
        JutsuUtil.sound(level, c, SoundEvents.FIRECHARGE_USE, 1.2f, 0.4f);
        JutsuUtil.sound(level, c, SoundEvents.BLAZE_SHOOT, 0.8f, 0.5f);
        strainEyes(p, d);
        return true;
    }

    /** Lights black flames on and around a spot (a small patch, each on solid ground). Returns how many were lit. */
    private static int placeFlames(ServerLevel level, ServerPlayer p, BlockPos center) {
        int placed = 0;
        for (int dx = -1; dx <= 1; dx++) {
            for (int dz = -1; dz <= 1; dz++) {
                boolean middle = dx == 0 && dz == 0;
                if (!middle && level.getRandom().nextFloat() < 0.35f) continue; // ragged edges
                for (int dy = 1; dy >= -4; dy--) {
                    BlockPos pos = center.offset(dx, dy, dz);
                    if (AmaterasuFireBlock.canBurnAt(level, pos) && level.mayInteract(p, pos)) {
                        level.setBlock(pos, ModBlocks.AMATERASU_FIRE.get().defaultBlockState(), 3);
                        placed++;
                        break;
                    }
                }
            }
        }
        return placed;
    }

    /** Sneaking with the Mangekyou on: every black flame within the radius goes out, on the ground and on creatures. */
    public static int extinguish(ServerPlayer p) {
        ServerLevel level = p.serverLevel();
        int r = Config.i(Config.AMATERASU_EXTINGUISH_RADIUS);
        BlockPos c = p.blockPosition();
        int count = 0;
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int dx = -r; dx <= r; dx++) {
            for (int dz = -r; dz <= r; dz++) {
                if (dx * dx + dz * dz > r * r) continue;
                for (int dy = -r; dy <= r; dy++) {
                    pos.set(c.getX() + dx, c.getY() + dy, c.getZ() + dz);
                    if (level.getBlockState(pos).is(ModBlocks.AMATERASU_FIRE.get())) {
                        AmaterasuFireBlock.putOut(level, pos.immutable());
                        count++;
                    }
                }
            }
        }
        for (LivingEntity e : level.getEntitiesOfClass(LivingEntity.class, new AABB(c).inflate(r))) {
            double hx = e.getX() - p.getX(), hz = e.getZ() - p.getZ();
            if (hx * hx + hz * hz <= r * r && e.hasEffect(ModEffects.AMATERASU.get())) {
                e.removeEffect(ModEffects.AMATERASU.get());
                level.sendParticles(ParticleTypes.LARGE_SMOKE, e.getX(), e.getY() + e.getBbHeight() / 2, e.getZ(), 8, 0.3, 0.3, 0.3, 0.01);
                count++;
            }
        }
        if (count > 0) {
            JutsuUtil.sound(level, p.position(), SoundEvents.FIRE_EXTINGUISH, 1.0f, 0.6f);
            p.displayClientMessage(Component.translatable("message.shinobiarts.amaterasu_extinguished").withStyle(ChatFormatting.DARK_GRAY), true);
        }
        return count;
    }

    // ---------------------------------------------------------------- Kamui

    private static boolean startKamui(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        d.setIntangibleUntil(now + Config.i(Config.KAMUI_SECONDS) * 20L);
        swirl(p.serverLevel(), p.position().add(0, 1, 0), 1.2, 40);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 1.0f, 0.5f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_on").withStyle(ChatFormatting.DARK_PURPLE), true);
        return true;
    }

    /** Ends Kamui's intangibility (time up, out of chakra, eyes off, or Jutsu 2 pressed again); starts its cooldown. */
    public static void endIntangible(ServerPlayer p, NinjaData d) {
        long now = p.level().getGameTime();
        d.setIntangibleUntil(0);
        d.setCooldown(Technique.KAMUI.cooldownId(), now + Technique.KAMUI.cooldownTicks());
        swirl(p.serverLevel(), p.position().add(0, 1, 0), 0.8, 25);
        JutsuUtil.sound(p.level(), p.position(), SoundEvents.ENDERMAN_TELEPORT, 0.8f, 0.8f);
        p.displayClientMessage(Component.translatable("message.shinobiarts.kamui_off").withStyle(ChatFormatting.GRAY), true);
        ModNetwork.sync(p);
        SharinganManager.updateLook(p);
    }

    /** Tears at the creature you look at: half its max health (capped for bosses), ignoring armor. */
    private static boolean kamuiSnap(ServerPlayer p, NinjaData d) {
        LivingEntity target = JutsuUtil.rayTarget(p, Config.i(Config.KAMUI_SNAP_RANGE));
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        float damage = target.getMaxHealth() * Config.f(Config.KAMUI_SNAP_DAMAGE);
        if (target.getType().is(net.minecraftforge.common.Tags.EntityTypes.BOSSES)) {
            damage = Math.min(damage, Config.f(Config.KAMUI_SNAP_BOSS_MAX));
        }
        Vec3 c = target.getBoundingBox().getCenter();
        swirl(level, c, Math.max(0.8, target.getBbWidth()), 60);
        level.sendParticles(ParticleTypes.PORTAL, c.x, c.y, c.z, 60, 0.4, 0.4, 0.4, 0.6);
        target.hurt(ModDamage.kamui(level, p), damage);
        JutsuUtil.sound(level, c, SoundEvents.ENDERMAN_TELEPORT, 1.2f, 0.4f);
        JutsuUtil.sound(level, c, SoundEvents.PLAYER_ATTACK_CRIT, 1.0f, 0.5f);
        strainEyes(p, d);
        return true;
    }

    /** A dark spiral, Kamui's warp. */
    private static void swirl(ServerLevel level, Vec3 c, double radius, int points) {
        for (int i = 0; i < points; i++) {
            double t = i / (double) points;
            double a = t * Math.PI * 6;
            double r = radius * (1 - t);
            level.sendParticles(KAMUI_DUST, c.x + Math.cos(a) * r, c.y + (t - 0.5) * 0.6, c.z + Math.sin(a) * r, 1, 0, 0, 0, 0);
        }
    }

    // ---------------------------------------------------------------- Genjutsu

    /** An illusion on the creature you look at: longer and farther with each stage; the Mangekyou also roots them. */
    private static boolean genjutsu(ServerPlayer p, NinjaData d) {
        int stage = d.getSharinganStage();
        LivingEntity target = JutsuUtil.rayTarget(p, 10 + 4 * stage);
        if (target == null) {
            noTarget(p);
            return false;
        }
        ServerLevel level = p.serverLevel();
        int duration = Math.round((40 + 20 * stage) * d.genjutsuMultiplier());
        JutsuEffects.applyIllusion(target, duration);
        if (stage == Dojutsu.MANGEKYOU) target.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 40, 9));
        if (target instanceof ServerPlayer victim) {
            victim.displayClientMessage(Component.translatable("message.shinobiarts.caught_in_genjutsu", p.getDisplayName())
                    .withStyle(ChatFormatting.DARK_RED), true);
        }
        Vec3 e = target.getEyePosition();
        level.sendParticles(GENJUTSU_DUST, e.x, e.y, e.z, 30, 0.4, 0.3, 0.4, 0.0);
        level.sendParticles(ParticleTypes.SQUID_INK, e.x, e.y, e.z, 10, 0.3, 0.2, 0.3, 0.01);
        JutsuUtil.line(level, GENJUTSU_DUST, p.getEyePosition(), e, 0.8, 1, 0.05);
        JutsuUtil.sound(level, target.position(), SoundEvents.ELDER_GUARDIAN_CURSE, 0.6f, 1.6f);
        if (stage == Dojutsu.MANGEKYOU) strainEyes(p, d);
        return true;
    }

    // ================================================================ every tick

    /** Sneak-to-extinguish, Kamui's upkeep and timer, and keeping other players' view of this player up to date. */
    public static void tick(ServerPlayer p, NinjaData d, long now) {
        DojutsuSlot.sync(p);
        if (p.tickCount % 20 == 0) DojutsuSlot.removeStrayEyes(p);
        boolean crouching = p.isShiftKeyDown();
        if (crouching && !d.wasCrouching() && d.isMangekyouActive() && d.getMangekyouDesign().hasAmaterasu()) extinguish(p);
        d.setWasCrouching(crouching);

        if (d.getIntangibleUntil() != 0) {
            if (now >= d.getIntangibleUntil() || !d.isMangekyouActive() || !d.getMangekyouDesign().hasKamui()) {
                endIntangible(p, d);
            } else {
                if (p.tickCount % 20 == 0 && !p.getAbilities().instabuild) {
                    float drain = Config.f(Config.KAMUI_DRAIN);
                    if (d.getChakra() < drain) {
                        endIntangible(p, d);
                        return;
                    }
                    d.consumeChakra(drain);
                }
                if (p.tickCount % 3 == 0) {
                    double a = p.tickCount * 0.5;
                    p.serverLevel().sendParticles(KAMUI_DUST, p.getX() + Math.cos(a) * 0.7, p.getY() + 0.2 + (p.tickCount % 18) / 10.0,
                            p.getZ() + Math.sin(a) * 0.7, 2, 0.05, 0.05, 0.05, 0.0);
                }
                p.resetFallDistance();
            }
        }
        if (p.tickCount % 5 == 0) SharinganManager.updateLook(p);
    }

    /** Tells a player what their Mangekyou's pattern lets them do. */
    public static void explain(ServerPlayer p, NinjaData d) {
        p.sendSystemMessage(Component.translatable("message.shinobiarts.mangekyou_techniques." + d.getMangekyouDesign().id())
                .withStyle(ChatFormatting.GOLD));
    }
}
