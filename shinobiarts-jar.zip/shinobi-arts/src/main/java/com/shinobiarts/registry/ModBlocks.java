package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import com.shinobiarts.block.EarthWallBlock;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.SoundType;
import net.minecraft.world.level.block.state.BlockBehaviour;
import net.minecraft.world.level.material.MapColor;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

public final class ModBlocks {
    public static final DeferredRegister<Block> BLOCKS = DeferredRegister.create(ForgeRegistries.BLOCKS, ShinobiArts.MODID);

    /** Temporary wall raised by Earth Release: Earth Wall. Crumbles on its own. */
    public static final RegistryObject<Block> EARTH_WALL = BLOCKS.register("earth_wall", () -> new EarthWallBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.DIRT)
                    .strength(1.5f, 6.0f)
                    .sound(SoundType.GRAVEL)
                    .noLootTable()));

    /** Amaterasu's black flames (Jutsu 1 of the Itachi, Sasuke and Eternal Mangekyou). */
    public static final RegistryObject<Block> AMATERASU_FIRE = BLOCKS.register("amaterasu_fire", () -> new com.shinobiarts.block.AmaterasuFireBlock(
            BlockBehaviour.Properties.of()
                    .mapColor(MapColor.COLOR_BLACK)
                    .noCollission()
                    .strength(-1.0f, 3600000.0f)
                    .lightLevel(state -> 5)
                    .sound(SoundType.WOOL)
                    .pushReaction(net.minecraft.world.level.material.PushReaction.DESTROY)
                    .noLootTable()));

    private ModBlocks() {}
}
