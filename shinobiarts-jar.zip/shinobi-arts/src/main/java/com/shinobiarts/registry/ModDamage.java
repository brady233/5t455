package com.shinobiarts.registry;

import com.shinobiarts.ShinobiArts;
import net.minecraft.core.registries.Registries;
import net.minecraft.resources.ResourceKey;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.damagesource.DamageType;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.Level;

import javax.annotation.Nullable;

/** Custom damage types (defined in data/shinobiarts/damage_type/*.json) for proper death messages. */
public final class ModDamage {
    public static final ResourceKey<DamageType> JUTSU = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("jutsu"));
    public static final ResourceKey<DamageType> AMATERASU = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("amaterasu"));
    /** Kamui snap: ignores armor, shields and protection enchantments (data/minecraft/tags/damage_type). */
    public static final ResourceKey<DamageType> KAMUI = ResourceKey.create(Registries.DAMAGE_TYPE, ShinobiArts.id("kamui"));

    public static DamageSource jutsu(Level level, @Nullable Entity direct, @Nullable Entity causing) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(JUTSU), direct, causing);
    }

    public static DamageSource amaterasu(Level level) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(AMATERASU));
    }

    public static DamageSource kamui(Level level, Entity attacker) {
        return new DamageSource(level.registryAccess().registryOrThrow(Registries.DAMAGE_TYPE).getHolderOrThrow(KAMUI), attacker, attacker);
    }

    private ModDamage() {}
}
