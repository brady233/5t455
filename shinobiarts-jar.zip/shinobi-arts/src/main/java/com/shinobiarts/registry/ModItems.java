package com.shinobiarts.registry;

import com.shinobiarts.Config;
import com.shinobiarts.ShinobiArts;
import com.shinobiarts.item.ChakraPaperItem;
import com.shinobiarts.item.ChakraPillItem;
import com.shinobiarts.item.CoinItem;
import com.shinobiarts.item.ExpBottleItem;
import com.shinobiarts.item.ExplosiveTagItem;
import com.shinobiarts.item.FrogWalletItem;
import com.shinobiarts.item.JutsuScrollItem;
import com.shinobiarts.item.NatureScrollItem;
import com.shinobiarts.item.NinjaWeaponItem;
import com.shinobiarts.item.ReleaseItem;
import com.shinobiarts.item.SharinganEyeItem;
import com.shinobiarts.item.SharinganItem;
import com.shinobiarts.item.XpBoostItem;
import com.shinobiarts.item.ThrownToolItem;
import com.shinobiarts.jutsu.Jutsu;
import com.shinobiarts.jutsu.Jutsus;
import com.shinobiarts.ninja.ChakraNature;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.food.FoodProperties;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.Rarity;
import net.minecraft.world.item.Tiers;
import net.minecraftforge.registries.DeferredRegister;
import net.minecraftforge.registries.ForgeRegistries;
import net.minecraftforge.registries.RegistryObject;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister<Item> ITEMS = DeferredRegister.create(ForgeRegistries.ITEMS, ShinobiArts.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS = DeferredRegister.create(Registries.CREATIVE_MODE_TAB, ShinobiArts.MODID);

    // ---------------------------------------------------------------- release scrolls (equip to use jutsu)
    public static final Map<ChakraNature, RegistryObject<Item>> RELEASES = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature release : ChakraNature.RELEASES) {
            RELEASES.put(release, ITEMS.register("release_" + release.id(),
                    () -> new ReleaseItem(release, new Item.Properties().stacksTo(1).rarity(Rarity.UNCOMMON))));
        }
    }

    // ---------------------------------------------------------------- ninja tools & weapons
    /** Stackable throwing knife that is also a decent melee weapon (5 damage). */
    public static final RegistryObject<Item> KUNAI = ITEMS.register("kunai",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(16), 2.0f, 12, 4.0, -2.0));
    public static final RegistryObject<Item> SHURIKEN = ITEMS.register("shuriken",
            () -> new ThrownToolItem(new Item.Properties().stacksTo(32), 2.6f, 6, 0.0, 0.0));
    public static final RegistryObject<Item> EXPLOSIVE_TAG = ITEMS.register("explosive_tag",
            () -> new ExplosiveTagItem(new Item.Properties().stacksTo(16)));

    // Named weapons. Damage is in the "weapons" config section; attack speed shown = 4 + the value here.
    /** Zabuza's giant cleaver: 32 damage, slow, +1 reach, repairs itself on hit. */
    public static final RegistryObject<Item> ZABUZA_BLADE = ITEMS.register("zabuza_blade",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.ZABUZA_DAMAGE, -3.2f, 1.0, NinjaWeaponItem.Ability.SELF_REPAIR,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    /** Kisame's living sword: 34 damage, slowest, +1 reach, eats chakra. */
    public static final RegistryObject<Item> SAMEHADA = ITEMS.register("samehada",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.SAMEHADA_DAMAGE, -3.3f, 1.0, NinjaWeaponItem.Ability.CHAKRA_DRAIN,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    /** Hidan's triple-bladed scythe: 24 damage, +1.5 reach, heals on hit. */
    public static final RegistryObject<Item> HIDAN_SCYTHE = ITEMS.register("hidan_scythe",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.HIDAN_SCYTHE_DAMAGE, -3.1f, 1.5, NinjaWeaponItem.Ability.LIFESTEAL,
                    new Item.Properties().rarity(Rarity.EPIC).fireResistant()));
    public static final RegistryObject<Item> SWORD_OF_FIRE = ITEMS.register("sword_of_fire",
            () -> new NinjaWeaponItem(Tiers.NETHERITE, Config.SWORD_OF_FIRE_DAMAGE, -2.8f, 0.0, NinjaWeaponItem.Ability.BURN,
                    new Item.Properties().rarity(Rarity.RARE).fireResistant()));
    public static final RegistryObject<Item> SHAKUJO = ITEMS.register("shakujo",
            () -> new NinjaWeaponItem(Tiers.DIAMOND, Config.SHAKUJO_DAMAGE, -2.9f, 1.5, NinjaWeaponItem.Ability.KNOCKBACK,
                    new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> KUSANAGI = ITEMS.register("kusanagi",
            () -> new NinjaWeaponItem(Tiers.DIAMOND, Config.KUSANAGI_DAMAGE, -2.2f, 0.0, NinjaWeaponItem.Ability.CHIDORI_FLOW,
                    new Item.Properties().rarity(Rarity.RARE)));
    public static final RegistryObject<Item> KATANA = ITEMS.register("katana",
            () -> new NinjaWeaponItem(Tiers.IRON, Config.KATANA_DAMAGE, -2.4f, 0.0, NinjaWeaponItem.Ability.NONE,
                    new Item.Properties()));

    /** Everything shown in the "Ninja Tools" creative tab (kept out of the main tab). */
    public static final List<RegistryObject<Item>> NINJA_TOOLS = List.of(KUNAI, SHURIKEN, EXPLOSIVE_TAG,
            KATANA, KUSANAGI, SWORD_OF_FIRE, SHAKUJO, HIDAN_SCYTHE, ZABUZA_BLADE, SAMEHADA);

    // ---------------------------------------------------------------- consumables & progression
    public static final RegistryObject<Item> CHAKRA_PILL = ITEMS.register("chakra_pill",
            () -> new ChakraPillItem(new Item.Properties().stacksTo(16).food(new FoodProperties.Builder()
                    .nutrition(2).saturationMod(0.2f).alwaysEat().fast().build())));
    public static final RegistryObject<Item> CHAKRA_PAPER = ITEMS.register("chakra_paper",
            () -> new ChakraPaperItem(new Item.Properties().stacksTo(16)));
    public static final RegistryObject<Item> EXP_BOTTLE = ITEMS.register("exp_bottle",
            () -> new ExpBottleItem(new Item.Properties().stacksTo(64).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> BLANK_SCROLL = ITEMS.register("blank_scroll",
            () -> new Item(new Item.Properties()));

    // ---------------------------------------------------------------- ryo
    public static final Map<CoinItem.Coin, RegistryObject<Item>> COINS = new EnumMap<>(CoinItem.Coin.class);

    static {
        for (CoinItem.Coin coin : CoinItem.Coin.values()) {
            COINS.put(coin, ITEMS.register(coin.id() + "_ryo", () -> new CoinItem(coin, new Item.Properties().stacksTo(64))));
        }
    }

    public static final RegistryObject<Item> NINJA_BANDIT_SPAWN_EGG = ITEMS.register("ninja_bandit_spawn_egg",
            () -> new net.minecraftforge.common.ForgeSpawnEggItem(ModEntities.NINJA_BANDIT, 0x2B2B33, 0xB0332B, new Item.Properties()));

    /** A Sharingan eye taken in PvP; right-click to implant it. */
    public static final RegistryObject<Item> SHARINGAN_EYE = ITEMS.register("sharingan_eye",
            () -> new SharinganEyeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));
    // XP boost tokens: multiplier x duration
    public static final RegistryObject<Item> XP_BOOST_15_30 = ITEMS.register("xp_boost_1_5x_30m",
            () -> new XpBoostItem(1.5f, 30, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> XP_BOOST_15_60 = ITEMS.register("xp_boost_1_5x_60m",
            () -> new XpBoostItem(1.5f, 60, new Item.Properties().stacksTo(16).rarity(Rarity.UNCOMMON)));
    public static final RegistryObject<Item> XP_BOOST_25_30 = ITEMS.register("xp_boost_2_5x_30m",
            () -> new XpBoostItem(2.5f, 30, new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));
    public static final RegistryObject<Item> XP_BOOST_25_60 = ITEMS.register("xp_boost_2_5x_60m",
            () -> new XpBoostItem(2.5f, 60, new Item.Properties().stacksTo(16).rarity(Rarity.RARE)));

    /** Worn in the dojutsu slot: shows Sharingan eyes on the wearer's face. */
    public static final RegistryObject<Item> SHARINGAN = ITEMS.register("sharingan",
            () -> new SharinganItem(new Item.Properties().rarity(Rarity.EPIC)));
    /** The eyes you've switched on (V), shown in the dojutsu slot while they're on. Not in any creative tab. */
    public static final RegistryObject<Item> ACTIVE_EYE = ITEMS.register("active_eye",
            () -> new com.shinobiarts.item.ActiveEyeItem(new Item.Properties().stacksTo(1).rarity(Rarity.EPIC)));

    public static final RegistryObject<Item> FROG_WALLET = ITEMS.register("frog_wallet",
            () -> new FrogWalletItem(new Item.Properties().stacksTo(1)));

    // ---------------------------------------------------------------- scrolls (one per jutsu / nature)
    public static final Map<String, RegistryObject<Item>> JUTSU_SCROLLS = new LinkedHashMap<>();
    public static final Map<ChakraNature, RegistryObject<Item>> NATURE_SCROLLS = new EnumMap<>(ChakraNature.class);

    static {
        for (ChakraNature nature : ChakraNature.NATURES) {
            NATURE_SCROLLS.put(nature, ITEMS.register("nature_scroll_" + nature.id(),
                    () -> new NatureScrollItem(nature, new Item.Properties().stacksTo(16).rarity(Rarity.RARE))));
        }
        // Registered from D-rank to S-rank so the creative tab lists them in that order.
        List<Jutsu> byRank = new ArrayList<>(Jutsus.all());
        byRank.sort(Comparator.comparing(Jutsu::rank));
        for (Jutsu jutsu : byRank) {
            JUTSU_SCROLLS.put(jutsu.id(), ITEMS.register("scroll_" + jutsu.id(),
                    () -> new JutsuScrollItem(jutsu, new Item.Properties().stacksTo(16).rarity(rarityFor(jutsu)))));
        }
    }

    public static final RegistryObject<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts"))
            .icon(() -> new ItemStack(RELEASES.get(ChakraNature.FIRE).get()))
            .displayItems((params, output) -> ITEMS.getEntries().forEach(entry -> {
                if (!NINJA_TOOLS.contains(entry) && entry != ACTIVE_EYE) output.accept(entry.get());
            }))
            .build());
    public static final RegistryObject<CreativeModeTab> TOOLS_TAB = TABS.register("ninja_tools", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.shinobiarts.ninja_tools"))
            .icon(() -> new ItemStack(KUNAI.get()))
            .withTabsBefore(TAB.getKey())
            .displayItems((params, output) -> NINJA_TOOLS.forEach(entry -> output.accept(entry.get())))
            .build());

    public static Item coin(CoinItem.Coin coin) {
        return COINS.get(coin).get();
    }

    public static Item release(ChakraNature release) {
        return RELEASES.get(release).get();
    }

    private static Rarity rarityFor(Jutsu jutsu) {
        return jutsu.rank().rarity();
    }

    private ModItems() {}
}
