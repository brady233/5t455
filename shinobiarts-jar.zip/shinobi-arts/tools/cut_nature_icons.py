"""Cuts the five nature icons out of tools/source_art/natures_chart.png (provided art).
Run: python3 tools/cut_nature_icons.py"""
import math
import os
from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art", "natures_chart.png")
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "nature")
os.makedirs(OUT, exist_ok=True)

# Centers of each octagon in the 225x225 chart, and the octagon apothem (center to flat edge, incl. outline).
CENTERS = {"fire": (112.0, 30.5), "wind": (189.5, 86.5), "lightning": (160.5, 178.0),
           "earth": (64.5, 178.0), "water": (34.0, 87.0)}
APOTHEM = 19.5
SIZE = 64  # output icon size (scaled down in-game as needed)


def cut(name, cx, cy):
    src = Image.open(SRC).convert("RGBA")
    half = APOTHEM + 1.5
    box = (int(cx - half), int(cy - half), int(math.ceil(cx + half)), int(math.ceil(cy + half)))
    crop = src.crop(box)
    w, h = crop.size
    # mask everything outside the octagon (removes background and arrows)
    for y in range(h):
        for x in range(w):
            dx = abs(x + box[0] + 0.5 - cx)
            dy = abs(y + box[1] + 0.5 - cy)
            if dx > APOTHEM or dy > APOTHEM or dx + dy > APOTHEM * math.sqrt(2):
                crop.putpixel((x, y), (0, 0, 0, 0))
    icon = crop.resize((SIZE, SIZE), Image.LANCZOS)
    icon.save(os.path.join(OUT, name + ".png"))
    return icon


if __name__ == "__main__":
    for n, (x, y) in CENTERS.items():
        cut(n, x, y)
    print("cut", len(CENTERS), "nature icons")
