"""
Brings the imported jutsu / eye art (tools/source_art/jutsu and tools/source_art/sharingan, from the asset pack)
into the mod, and draws the eye technique icons that the pack doesn't have:

  textures/block/fire_black_layer_<0|1>.png (+ .mcmeta)  Amaterasu's black flames (animated, 32 frames)
  textures/entity/jutsu/fireball.png                     the Great Fireball sprite
  textures/entity/jutsu/water_ball.png                   the Water Bullet sprite (the pack's water swatch, made round)
  textures/entity/lightning_armor.png                    Lightning Armor's crackling shell
  textures/gui/mangekyou_icon_<sasuke|obito|eternal>.png the Mangekyou patterns in the HUD's eye slot
  textures/gui/eye_<amaterasu|kamui|kamui_snap|genjutsu>.png  the eye technique icons on the HUD
  textures/item/empty_dojutsu_slot.png                   the grey Sharingan in the empty dojutsu slot
  textures/nature/<fire|water|wind|lightning|earth>.png  sharper release emblems (and the release item icons)

Run: python3 tools/import_jutsu_art.py   (then python3 tools/make_sharingan.py for the faces and flashes)
"""
import json
import math
import os

from PIL import Image, ImageDraw, ImageFilter

HERE = os.path.dirname(os.path.abspath(__file__))
SRC = os.path.join(HERE, "source_art")
TEX = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures")


def out(*parts):
    path = os.path.join(TEX, *parts)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    return path


def src(*parts):
    return Image.open(os.path.join(SRC, *parts)).convert("RGBA")


def black_flames():
    for i in (0, 1):
        src("jutsu", f"fire_black_layer_{i}.png").save(out("block", f"fire_black_layer_{i}.png"))
        with open(out("block", f"fire_black_layer_{i}.png.mcmeta"), "w") as f:
            json.dump({"animation": {"frametime": 1}}, f, indent=2)


def water_ball():
    """The pack's water texture (an 8x16 strip in the left half of its 16x16 file) wrapped into a glossy round drop."""
    size, ss = 32, 8
    strip = src("jutsu", "water_ball.png").crop((0, 0, 8, 16))
    tile = Image.new("RGBA", (16, 16))
    tile.paste(strip, (0, 0))
    tile.paste(strip, (8, 0))
    tile = tile.resize((size * ss, size * ss), Image.NEAREST)
    n = size * ss
    c, r = n / 2, n * 0.46
    shaded = Image.new("RGBA", (n, n), (0, 0, 0, 0))
    px, tp = shaded.load(), tile.load()
    for y in range(n):
        for x in range(n):
            dx, dy = (x - c) / r, (y - c) / r
            dist = math.hypot(dx, dy)
            if dist > 1:
                continue
            light = 1.15 - 0.55 * dist ** 2 - 0.25 * (dx + dy) / 2  # brighter toward the top-left, darker rim
            cr, cg, cb, ca = tp[x, y]
            px[x, y] = (min(255, int(cr * light)), min(255, int(cg * light)), min(255, int(cb * light)), min(255, int(ca * 1.25)))
    d = ImageDraw.Draw(shaded)
    d.ellipse([c - r, c - r, c + r, c + r], outline=(25, 45, 170, 255), width=ss)
    hl = r * 0.22  # shine
    d.ellipse([c - r * 0.45 - hl, c - r * 0.5 - hl, c - r * 0.45 + hl, c - r * 0.5 + hl], fill=(235, 245, 255, 220))
    shaded.resize((size, size), Image.LANCZOS).save(out("entity", "jutsu", "water_ball.png"))


def copies():
    src("jutsu", "fireball.png").save(out("entity", "jutsu", "fireball.png"))
    src("jutsu", "electric_armor.png").save(out("entity", "lightning_armor.png"))
    for design, name in (("sasuke", "sasuke"), ("obito", "obito"), ("eternal", "eterna")):
        src("sharingan", f"mangekyosharingan_{name}.png").resize((64, 64), Image.LANCZOS).save(out("gui", f"mangekyou_icon_{design}.png"))
    # Amaterasu's icon: the pack's black fireball, kept pixel-sharp
    src("jutsu", "black_fireball.png").resize((64, 64), Image.NEAREST).save(out("gui", "eye_amaterasu.png"))


def release_emblems():
    natures = {"fire": "katon", "water": "suiton", "wind": "futon", "lightning": "raiton", "earth": "doton"}
    for nature, name in natures.items():
        icon = src("jutsu", name + ".png").resize((64, 64), Image.LANCZOS)
        icon.save(out("nature", nature + ".png"))
        open(out("nature", "." + nature + ".provided"), "w").close()
        icon.resize((32, 32), Image.LANCZOS).save(out("item", "release_" + nature + ".png"))


def _disc(size):
    s = size * 8
    return Image.new("RGBA", (s, s), (0, 0, 0, 0)), s


def kamui_icon(snap=False):
    """A dark spiral warp (Kamui); the snap version has a red target ring and a burst at the middle."""
    img, s = _disc(64)
    d = ImageDraw.Draw(img)
    c = s / 2
    d.ellipse([c - s * 0.47, c - s * 0.47, c + s * 0.47, c + s * 0.47], fill=(38, 16, 58, 255), outline=(10, 4, 16, 255), width=s // 40)
    for arm in range(3):  # three arms spiralling in
        pts = []
        for i in range(60):
            t = i / 59
            a = arm * 2 * math.pi / 3 + t * 3.4 * math.pi
            r = s * 0.44 * (1 - t) ** 0.9
            pts.append((c + math.cos(a) * r, c + math.sin(a) * r))
        for i in range(len(pts) - 1):
            w = max(2, int(s * 0.075 * (1 - i / len(pts)) + s * 0.012))
            d.line([pts[i], pts[i + 1]], fill=(120, 70, 170, 255) if arm == 0 else (80, 40, 120, 255), width=w)
    d.ellipse([c - s * 0.08, c - s * 0.08, c + s * 0.08, c + s * 0.08], fill=(5, 0, 8, 255))
    if snap:
        d.ellipse([c - s * 0.36, c - s * 0.36, c + s * 0.36, c + s * 0.36], outline=(220, 30, 40, 255), width=s // 28)
        for k in range(8):
            a = k * math.pi / 4
            d.line([(c + math.cos(a) * s * 0.1, c + math.sin(a) * s * 0.1), (c + math.cos(a) * s * 0.24, c + math.sin(a) * s * 0.24)],
                   fill=(255, 210, 210, 255), width=s // 36)
    return img.resize((64, 64), Image.LANCZOS)


def genjutsu_icon():
    """A red eye of rings pulling inward, with a purple haze: the illusion."""
    img, s = _disc(64)
    d = ImageDraw.Draw(img)
    c = s / 2
    d.ellipse([c - s * 0.47, c - s * 0.47, c + s * 0.47, c + s * 0.47], fill=(70, 20, 90, 255), outline=(15, 4, 20, 255), width=s // 40)
    for k, rr in enumerate((0.40, 0.31, 0.22)):
        col = (200, 20, 30, 255) if k % 2 == 0 else (40, 6, 12, 255)
        d.ellipse([c - s * rr, c - s * rr, c + s * rr, c + s * rr], fill=col)
    for k in range(3):  # three tomoe swirling
        a = -math.pi / 2 + k * 2 * math.pi / 3
        tr = s * 0.17
        for j in range(10):
            b = a + j * 0.09
            w = s * 0.05 * (1 - j / 10)
            x, y = c + math.cos(b) * tr, c + math.sin(b) * tr
            d.ellipse([x - w, y - w, x + w, y + w], fill=(12, 2, 6, 255))
    d.ellipse([c - s * 0.06, c - s * 0.06, c + s * 0.06, c + s * 0.06], fill=(12, 2, 6, 255))
    glow = img.filter(ImageFilter.GaussianBlur(s * 0.01))
    return glow.resize((64, 64), Image.LANCZOS)


def empty_dojutsu_slot():
    """A 3-tomoe Sharingan as grey line art, matching vanilla's empty armor slot icons (one grey, 16x16)."""
    s = 16 * 8
    img = Image.new("L", (s, s), 0)
    d = ImageDraw.Draw(img)
    c = s / 2
    r = s * 0.44
    d.ellipse([c - r, c - r, c + r, c + r], outline=255, width=s // 16)          # the iris' rim
    tr = r * 0.56
    for k in range(3):                                                          # three tomoe with tails
        a = -math.pi / 2 + k * 2 * math.pi / 3
        dot = r * 0.2
        for j in range(10):
            b = a + math.radians(8 + j * 5)
            w = dot * (1 - j / 10) ** 1.2
            x, y = c + tr * math.cos(b), c + tr * math.sin(b)
            d.ellipse([x - w, y - w, x + w, y + w], fill=255)
        x, y = c + tr * math.cos(a), c + tr * math.sin(a)
        d.ellipse([x - dot, y - dot, x + dot, y + dot], fill=255)
    p = r * 0.2
    d.ellipse([c - p, c - p, c + p, c + p], fill=255)                            # pupil
    alpha = img.resize((16, 16), Image.LANCZOS).point(lambda v: 255 if v > 100 else 0)
    icon = Image.new("RGBA", (16, 16), (85, 85, 85, 255))
    icon.putalpha(alpha)
    icon.save(out("item", "empty_dojutsu_slot.png"))


ACTIVE_EYES = ["sharingan_icon_1", "sharingan_icon_2", "sharingan_icon_3", "sharingan_icon_4",
               "mangekyou_icon_sasuke", "mangekyou_icon_obito", "mangekyou_icon_eternal", "byakugan_icon"]


def active_eyes():
    """The switched-on eyes shown in the dojutsu slot (item/active_eye_<0-7>): the HUD's eye icons as items."""
    for i, name in enumerate(ACTIVE_EYES):
        Image.open(out("gui", name + ".png")).convert("RGBA").resize((32, 32), Image.LANCZOS).save(out("item", f"active_eye_{i}.png"))


def main():
    black_flames()
    water_ball()
    copies()
    release_emblems()
    kamui_icon().save(out("gui", "eye_kamui.png"))
    kamui_icon(snap=True).save(out("gui", "eye_kamui_snap.png"))
    genjutsu_icon().save(out("gui", "eye_genjutsu.png"))
    empty_dojutsu_slot()
    active_eyes()
    print("jutsu and eye art written")


if __name__ == "__main__":
    main()
