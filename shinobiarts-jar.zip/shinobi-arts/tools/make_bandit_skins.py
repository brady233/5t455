"""
Draws the three Ninja Bandit skins (textures/entity/ninja_bandit_<fire|water|earth>.png, 64x64 player-skin layout):
dark rogue-ninja outfit, cloth mask over the lower face, scratched-out headband plate, bandaged forearms and
shins, and a scarf/headband cloth in the bandit's nature colour. Run: python3 tools/make_bandit_skins.py
"""
import os
import random

from PIL import Image

HERE = os.path.dirname(os.path.abspath(__file__))
OUT = os.path.join(HERE, "..", "src", "main", "resources", "assets", "shinobiarts", "textures", "entity")

ELEMENTS = {"fire": (176, 40, 34), "water": (40, 92, 176), "earth": (128, 88, 46)}
SKIN, SKIN_DARK = (214, 168, 128), (186, 140, 104)
HAIR = (34, 28, 26)
SUIT, SUIT_DARK = (44, 44, 52), (30, 30, 36)
VEST = (70, 74, 60)
MASK = (24, 24, 28)
WRAP, WRAP_DARK = (206, 200, 186), (170, 164, 150)
METAL, METAL_DARK = (168, 172, 180), (110, 114, 122)


def shade(c, rng, amount=10):
    d = rng.randint(-amount, amount)
    return tuple(max(0, min(255, v + d)) for v in c) + (255,)


def fill(img, rng, x0, y0, x1, y1, color, noise=8):
    for y in range(y0, y1):
        for x in range(x0, x1):
            img.putpixel((x, y), shade(color, rng, noise))


def skin(cloth):
    rng = random.Random(hash(cloth) & 0xFFFF)
    img = Image.new("RGBA", (64, 64), (0, 0, 0, 0))
    # ---- head (8x8 faces): hair everywhere, then the face
    fill(img, rng, 0, 0, 32, 16, HAIR)
    fill(img, rng, 8, 8, 16, 16, SKIN, 6)                     # face
    for x in range(8, 16):
        img.putpixel((x, 8), shade(HAIR, rng))                # fringe
    for fx in (9, 10, 13, 14):                                # eyes
        img.putpixel((fx, 11), (240, 240, 240, 255) if fx in (9, 14) else (30, 24, 20, 255))
    fill(img, rng, 8, 12, 16, 16, MASK, 5)                    # cloth mask over nose and mouth
    fill(img, rng, 0, 13, 8, 16, MASK, 5)                     # mask wraps round the sides
    fill(img, rng, 16, 13, 24, 16, MASK, 5)
    # headband: cloth all round, scratched metal plate on the front
    for x0 in (0, 8, 16, 24):
        fill(img, rng, x0, 9, x0 + 8, 11, cloth, 8)
    fill(img, rng, 10, 9, 14, 11, METAL, 6)
    img.putpixel((10, 9), METAL_DARK + (255,))
    img.putpixel((11, 10), (40, 40, 44, 255))                 # the scratch through the village symbol
    img.putpixel((12, 9), (40, 40, 44, 255))
    img.putpixel((13, 10), (40, 40, 44, 255))
    fill(img, rng, 26, 11, 30, 13, cloth, 8)                  # headband knot tails at the back
    # ---- torso
    fill(img, rng, 16, 16, 40, 32, SUIT)
    fill(img, rng, 20, 20, 28, 32, VEST, 8)                   # flak vest front
    fill(img, rng, 32, 20, 40, 32, VEST, 8)                   # and back
    fill(img, rng, 23, 20, 25, 32, SUIT_DARK, 4)              # vest opening
    fill(img, rng, 16, 20, 40, 22, cloth, 10)                 # scarf round the neck
    fill(img, rng, 20, 22, 23, 25, cloth, 10)                 # scarf end hanging down
    fill(img, rng, 20, 29, 28, 30, (60, 44, 30), 6)           # belt
    fill(img, rng, 32, 29, 40, 30, (60, 44, 30), 6)
    # ---- arms (right: 40-56 x 16-32, left: 32-48 x 48-64)
    for ax, ay in ((40, 16), (32, 48)):
        fill(img, rng, ax, ay, ax + 16, ay + 16, SUIT)
        fill(img, rng, ax, ay + 10, ax + 16, ay + 15, WRAP, 6)    # bandaged forearms
        for y in range(ay + 10, ay + 15, 2):
            for x in range(ax, ax + 16):
                img.putpixel((x, y), shade(WRAP_DARK, rng, 4))
        fill(img, rng, ax, ay + 15, ax + 16, ay + 16, SKIN_DARK, 4)  # hands
        fill(img, rng, ax + 4, ay, ax + 8, ay + 4, SUIT_DARK, 4)
    # ---- legs (right: 0-16 x 16-32, left: 16-32 x 48-64)
    for lx, ly in ((0, 16), (16, 48)):
        fill(img, rng, lx, ly, lx + 16, ly + 16, SUIT_DARK)
        fill(img, rng, lx, ly + 9, lx + 16, ly + 14, WRAP, 6)     # shin wraps
        for y in range(ly + 10, ly + 14, 2):
            for x in range(lx, lx + 16):
                img.putpixel((x, y), shade(WRAP_DARK, rng, 4))
        fill(img, rng, lx, ly + 14, lx + 16, ly + 16, (50, 40, 34), 5)  # sandals
    return img


def main():
    os.makedirs(OUT, exist_ok=True)
    for name, cloth in ELEMENTS.items():
        skin(cloth).save(os.path.join(OUT, f"ninja_bandit_{name}.png"))
    print(f"{len(ELEMENTS)} bandit skins written")


if __name__ == "__main__":
    main()
